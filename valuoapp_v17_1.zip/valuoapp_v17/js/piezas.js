const CATALOGO = {
  "🚗 Carrocería Frontal": {
    "Capó": [
      "Capó","Bisagra Derecha de Capó","Bisagra Izquierda de Capó",
      "Moldura de Capó","Empaque de Capó","Insulador de Capó",
      "Recibidor de Chapa de Capó","Varilla de Capó",
      "Amortiguador Derecho de Capó","Amortiguador Izquierdo de Capó",
      "Picaporte o Seguro de Capó","Aislante de Calor",
      "Surtidor Derecho de Capó","Surtidor Izquierdo de Capó"
    ],
    "Farol Derecho": [
      "Farol Derecho","Filler Derecho","Elemento de Farol Derecho"
    ],
    "Farol Izquierdo": [
      "Farol Izquierdo","Filler Izquierdo","Elemento de Farol Izquierdo"
    ],
    "Parrilla Frontal": [
      "Parrilla Frontal","Base de Parrilla","Moldura Cromada de Parrilla",
      "Grapas de Parrilla","Filler Superior de Parrilla","Filler Inferior de Parrilla"
    ],
    "Emblema Delantero": [
      "Emblema Delantero","Base de Emblema"
    ],
    "Radar": [
      "Radar","Base de Radar"
    ],
    "Bomper Delantero": [
      "Bomper Delantero","Amortiguador de Impacto / Espuma",
      "Complemento Overfender Derecho","Complemento Overfender Izquierdo",
      "Via Derecha de Bomper","Via Izquierda de Bomper",
      "Cortesia Derecha","Cortesia Izquierda",
      "Rejilla Central Bomper Frontal","Rejilla Derecha de Bomper Frontal",
      "Rejilla Izquierda de Bomper Frontal",
      "Halógeno Derecho de Bomper","Halógeno Izquierdo de Bomper",
      "Refuerzo de Bomper","Guia Izquierda de Bomper","Guia Derecha de Bomper",
      "Cubierta de Gancho de Remolque",
      "Sensor de Proximidad LH","Sensor de Proximidad RH","Sensor de Proximidad Central",
      "Juego de Sensores de Proximidad","Ramal Eléctrico de Sensores",
      "Moldura RH Inferior de Bomper Cromada","Moldura RH Superior de Bomper Cromada",
      "Moldura LH Superior de Bomper Cromada","Moldura LH Inferior de Bomper Cromada",
      "Rejilla Inferior","Surtidor Derecho","Surtidor Izquierdo",
      "Cubierta de Surtidor Derecho","Cubierta de Surtidor Izquierdo",
      "Tuberia de Surtidores","Acople de Tuberia de Surtidores",
      "Tolva de Bomper Delantero","Placa Cubierta de Bomper",
      "Defensa de Bomper Delantero","Soporte de Cubierta de Bomper Delantero",
      "Marco de Placa","Porta Placa",
      "Cubierta Derecha Inferior","Cubierta Izquierda Inferior",
      "Cubierta Derecha Superior","Cubierta Izquierda Superior",
      "Moldura Inferior","Cubierta Central","Soporte Inferior RH","Soporte Superior RH"
    ],
    "Bomper Delantero Inferior": [
      "Bomper Delantero Inferior","Spoiler de Bomper",
      "Cubierta Inferior de Bomper","Cubierta Central",
      "Cubierta Derecha","Cubierta Izquierda",
      "Halógeno Izquierdo de Bomper","Rejilla Inferior"
    ],
    "Defensa Frontal": [
      "Defensa Frontal","Halógenos","Barra LED","Moldura de Defensa"
    ],
    "Marco de Radiador": [
      "Marco de Radiador","Chapa de Capó","Soporte de Chapa de Capó",
      "Guía de Aire Derecha","Guía Izquierda de Aire","Guía Inferior de Aire",
      "Tolva de Ventilador","Radiador","Condensador","Ventilador de Motor",
      "Depósito de Agua de Cricos","Pito","Caja de Resonancia",
      "Depósito Auxiliar de Radiador","Unidad de Control de Airbags",
      "Conector de Unidad de Control de Airbags",
      "Sensor de Airbag Conductor","Sensor de Airbag Copiloto",
      "Marco Superior de Radiador","Marco Inferior de Radiador",
      "Marco Izquierdo de Radiador","Marco Derecho de Radiador",
      "Cubierta Inferior Protectora","Rejilla Electrónica","Intercooler"
    ],
    "Guardafango Derecho": [
      "Guardafango Derecho","Moldura Esquinera de Guardafango",
      "Refuerzo de Guardafango","Lámpara de Via",
      "Moldura de Overfender","Lodera","Salpicadera RH"
    ],
    "Guardafango Izquierdo": [
      "Guardafango Izquierdo","Moldura Esquinera de Guardafango",
      "Salpicadera Izquierda","Lámpara de Via","Moldura de Overfender","Lodera"
    ],
    "Parabrisas Frontal": [
      "Parabrisas Frontal","Empaque Parabrisas","Polarizado",
      "Moldura Parabrisas","Tapasoles","Esperjo Retrovisor Interior",
      "Sensor de Lluvia","Cámara","Antena"
    ]
  },
  "🔴 Carrocería Trasera": {
    "Bomper Trasero": [
      "Bomper Trasero","Guia RH","Guia LH","Bomper Superior","Bomper Inferior",
      "Luz de Placa","Cubierta de Luz de Placa","Marco Porta Placa",
      "Cubierta de Gancho","Sensores de Retroceso",
      "Soporte RH de Bomper Trasero","Soporte LH de Bomper Trasero",
      "Amortiguador de Impacto","Juego de Grapas","Refuerzo de Bomper Trasero",
      "Rejilla Inferior","Lodera Trasera RH","Lodera Trasera LH",
      "Sensores de Proximidad","Camara de Retroceso","Guia Central","Spoiler"
    ],
    "Compuerta Trasera / Tapa de Baúl": [
      "Compuerta Trasera","Tapa de Baúl",
      "Interior de Tapa de Baúl","Aislante de Calor","Chapa de Baúl",
      "Tapicerías Internas de Costado Derecha","Tapicerías Internas de Costado Izquierda",
      "Llavin de Baul","Cubierta de Chapa","Cubierta Recibidor de Chapa Baul",
      "Luz de Placa","Cubierta de Luz de Placa","Alerón Trasero",
      "Moldura de Baúl","Emblemas","Marco Porta Placa",
      "Cubierta de Llanta","Llanta de Repuesto","Herramientas",
      "Bisagra LH de Tapa de Baul","Bisagra RH de Tapa de Baul",
      "Empaque de Tapa de Baul","Camara de Retroceso","Logo","Sticker"
    ],
    "Cubierta Trasera": [
      "Cubierta","Empaque Parabrisas Trasero","Polarizado","Desempañador","Antena"
    ],
    "Parabrisas Trasero": ["Parabrisas Trasero"],
    "Stop RH": ["Stop RH","Elementos","Arnes Electrico","Conector","Cromo RH - Accesorio"],
    "Stop LH": ["Stop LH","Elementos","Arnes Electrico","Conector","Cromo LH - Accesorio"],
    "Stop Interior RH": ["Stop Interior RH","Ventilador de Motor","Arnes Electrico","Conector"],
    "Stop Interior LH": ["Stop Interior LH","Elementos","Arnes Electrico","Conector"],
    "Panel Trasero": ["Panel Trasero","Cubierta","Tapiceria Interior"],
    "Compartimiento de Baúl": [
      "Compartimiento de Baúl","Llanta de Repuesto","Pin de Llanta de Repuesto",
      "Jack","Mica con Varilla","Llave de Ruedas","Durapax de Llanta de Repuesto",
      "Cubierta de Llanta de Repuesto","Alfombra de Compartimiento","Cono","Extintor",
      "Moldura de Piso de Baul","Tapa de Cofre Central","Tapa de Cofre Izquierdo",
      "Tapa de Cofre Derecho","Cofre Derecho","Cofre Izquierdo","Cofre Central",
      "Caja Porta Herramientas","Mecanismo Porta Llanta"
    ],
    "Piso de Baúl": ["Piso de Baúl"]
  },
  "🚪 Puertas y Laterales": {
    "Puerta Delantera Derecha": [
      "Puerta Delantera Derecha","Tapiceria","Manecilla Externa","Manecilla Interior",
      "Control de Subevidrio","Bocina","Vidrio","Máquina Sube Vidrio",
      "Cañuela de Vidrio","Moldura Botagua Exterior","Moldura Botagua Interior",
      "Refuerzo Interno","Burbuja","Vinil de Marco de Puerta",
      "Soporte de Estribo RH","Empaque","Moldura Decorativa","Freno de Puerta",
      "Bisagra Superior","Bisagra Inferior","Cromo de Manecilla RH - Accesorio","Chapa Del. RH"
    ],
    "Puerta Delantera Izquierda": [
      "Puerta Delantera Izquierda","Tapiceria","Manecilla Externa",
      "Base de Manecilla","Tapón de Manecilla","Empaque de Manecilla",
      "Sensor de Proximidad","Manecilla Interior","Cierre Central",
      "Bocina","Vidrio","Máquina Sube Vidrio","Cañuela de Vidrio",
      "Moldura Botagua Exterior","Moldura Botagua Interior",
      "Refuerzo Interno","Burbuja","Vinil de Marco de Puerta",
      "Chapa","Empaque","Moldura Decorativa","Freno de Puerta",
      "Bisagras Superior","Bisagra Inferior","Control Master",
      "Cromo de Manecilla LH - Accesorio"
    ],
    "Puerta Trasera Derecha": [
      "Puerta Trasera Derecha","Tapiceria","Manecilla Externa","Manecilla Interior",
      "Control de Subevidrio","Bocina","Vidrio","Polea de Cigüeñal",
      "Cañuela de Vidrio","Moldura Botagua Exterior","Moldura Botagua Interior",
      "Refuerzo Interno","Burbuja","Vinil de Marco de Puerta",
      "Chapa","Empaque","Moldura Decorativa","Freno de Puerta",
      "Bisagras Superior","Bisagra Inferior","Ventolera RH",
      "Cromo de Manecilla RH Tras. - Accesorio"
    ],
    "Puerta Trasera Izquierda": [
      "Puerta Trasera Izquierda","Tapiceria","Manecilla Externa","Manecilla Interior",
      "Control de Subevidrio","Bocina","Vidrio","Máquina Sube Vidrio",
      "Cañuela de Vidrio","Moldura Botagua Exterior","Moldura Botagua Interior",
      "Refuerzo Interno","Burbuja","Vinil de Marco de Puerta",
      "Chapa","Empaque","Moldura Decorativa","Freno de Puerta",
      "Bisagras Superior","Bisagra Inferior","Ventolera LH","Llavin",
      "Cromo de Manecilla LH Tras. - Accesorio"
    ],
    "Estribos": [
      "Estribo Colgante Derecho","Estribo Colgante Izquierdo",
      "Estribo Metálico Derecho","Estribo Metálico Izquierdo"
    ],
    "Retrovisor RH": ["Retrovisor RH","Cubierta de Retrovisor","Camara Sensor"],
    "Retrovisor LH": ["Retrovisor LH","Cubierta de Retrovisor","Camara Sensor"],
    "Faldon Derecho": [
      "Faldon Derecho","Caja de Rueda","Refuerzo","Overfender","Salpicadera","Lodera",
      "Rejilla de Ventilación","Base de Stop RH","Tapa de Combustible",
      "Tapon de Tanque de Combustible"
    ],
    "Faldon Izquierdo": [
      "Faldon Izquierdo","Caja de Rueda","Refuerzo","Overfender","Salpicadera","Lodera",
      "Rejilla de Ventilación","Tapa de Gasolina","Marco de Tapa de Baul",
      "Vidrio Fijo LH","Vidrio Fijo RH","Base de Stop LH","Tanque de Combustible"
    ],
    "Costado Derecho": [
      "Costado Derecho","Overfender de Costado Derecho",
      "Rejilla de Ventilacion RH","Stop Derecho","Caja de Rueda",
      "Tapiceria Interior","Salpicadera RH","Ventolera RH"
    ],
    "Costado Izquierdo": [
      "Costado Izquierdo","Overfender Trasero LH","Rejilla de Ventilacion LH",
      "Modulo de Bolsa de Aire","Sensor de Colision","Stop Izquierdo",
      "Caja de Rueda","Tapiceria Interna","Salpicadera Izquierda","Ventolera LH"
    ]
  },
  "🏗️ Chasis y Estructura": {
    "Puntas de Chasis": [
      "Punta de Chasis Delantero RH","Punta de Chasis Delantero LH",
      "Punta de Chasis Trasero RH","Punta de Chasis Trasero LH"
    ],
    "Pilarillo Derecho": ["Pilarillo Derecho","Molduras de Pilarillo","Tweeters","Bocina"],
    "Pilarillo Izquierdo": ["Pilarillo Izquierdo","Molduras de Pilarillo","Tweeters","Bocina"],
    "Pilarillo Intermedio Derecho": ["Pilarillo Intermedio Derecho","Moldura de Pilarillo","Bases de Cinturones de Seguridad"],
    "Pilarillo Intermedio Izquierdo": ["Pilarillo Intermedio Izquierdo","Moldura de Pilarillo","Bases de Cinturones de Seguridad"],
    "Pilarillo Trasero Derecho": ["Pilarillo Trasero Derecho","Moldura de Pilarillo","Bases de Cinturones de Seguridad"],
    "Techo": [
      "Techo","Tapicería de Techo","Bolsas de Aire de Cortina",
      "Barras de Techo","Parrilla de Techo","Sunroof",
      "Moldura Botagua de Techo RH","Moldura Botagua de Techo LH","Antena de Techo"
    ],
    "Cubierta": ["Cubierta","Moldura de Pilarillo","Bases de Cinturones de Seguridad"],
    "Caja de Rueda Delantera Derecha": ["Caja de Rueda Delantera Derecha","Refuerzo","Arnes Electrico"],
    "Caja de Rueda Delantera Izquierda": ["Caja de Rueda Delantera Izquierda","Refuerzo","Arnes Electrico"],
    "Estructura": ["Chasis Completo","Puente de Suspensión Delantero","Eje Trasero"],
    "Chasis Completo": ["Chasis Completo","Lavado de Chasis"]
  },
  "⚙️ Suspensión y Ruedas": {
    "Rin Delantero RH": ["Rin Delantero RH","Llanta","Copa Delantera"],
    "Rin Delantero LH": ["Rin Delantero LH","Llanta","Copa Delantera"],
    "Rin Trasero RH": ["Rin Trasero RH","Llanta","Copa Trasera"],
    "Rin Trasero LH": ["Rin Trasero LH","Llanta","Copa Trasera"],
    "Puente de Suspensión": [
      "Puente de Suspensión",
      "Amortiguador LH","Soporte de Amortiguador LH","Pernos de Amortiguador LH","Resorte Helicoidal LH",
      "Tijera Superior LH","Esfera de Tijera Superior LH","Pernos de Tijera Superior LH",
      "Tijera Inferior LH","Esfera de Tijera Inf LH","Pernos de Tijera Inferior LH",
      "Muñon Delantero LH","Retenedor de Bufa LH","Balero de Bufa LH","Pernos de Bufa LH",
      "Sensor ABS","Frenos LH","Disco de Freno LH","Manguera de Freno LH","Caliper de Freno LH","Purgar Frenos LH",
      "Flecha Delantera LH","Punta de Flecha LH","Polvera Externa","Sello de Flecha LH","Polvera Interna",
      "Barra Estabilizadora","Terminal Barra Estabilizadora LH","Terminal Barra Estabilizadora RH",
      "Soporte de Barra LH","Pernos de Soporte de Barra LH",
      "Soporte de Barra RH","Pernos de Soporte de Barra RH","Hules",
      "Cremallera","Terminal de Direccion LH","Terminal de Cremallera LH",
      "Terminal de Direccion RH","Terminal de Cremallera RH",
      "Amortiguador RH","Soporte de Amortiguador RH","Pernos de Amortiguador RH","Resorte Helicoidal RH",
      "Tijera Superior RH","Esfera de Tijera Superior RH","Pernos de Tijera Superior RH",
      "Tijera Inferior RH","Esfera de Tijera Inf RH","Pernos de Tijera Inferior RH",
      "Muñon Delantero RH","Retenedor de Bufa RH","Balero de Bufa RH","Pernos de Bufa RH",
      "Frenos RH","Disco de Freno RH","Manguera de Freno RH","Caliper de Freno RH","Purgar Frenos RH",
      "Flecha Delantera RH","Punta de Flecha RH","Eje de Flecha","Sello de Flecha RH",
      "Pernos de Puente de Suspension","Bujes de Puente","Perno de Tijera",
      "Bufa Delantera Derecha","Bufa Delantera Izquierda",
      "Bufa Trasera Derecha","Bufa Trasera Izquierda",
      "Balero de Bufa Delantero RH","Balero de Bufa Delantero LH",
      "Balero de Bufa Trasero RH","Balero de Bufa Trasero LH",
      "Corona de Doble Traccion","Cardan de Doble Traccion",
      "Hidrovac de Freno","Servo Freno","Bomba de Frenos","Correcion de Avance"
    ],
    "Eje Trasero / Puente": [
      "Eje Trasero / Puente","Moldura Cromada",
      "Bieleta Trasera RH","Tijera Inferior Trasera RH","Tijera Superior Trasera RH",
      "Tijera Trasera RH / Brazo Oscilante/Control",
      "Barra de Dirección Trasera RH","Resorte Helicoidal Trasera RH",
      "Muñon Derecho","Disco de Freno Trasero RH","Tambor de Freno Trasero RH",
      "Amortiguador Trasero LH","Bieleta Trasera LH",
      "Tijera Inferior Trasera LH","Tijera Superior Trasera LH",
      "Tijera Trasera Inf. LH / Brazo Oscilante",
      "Barra de Dirección Trasera LH","Resorte Helicoidal Trasera LH",
      "Bufa Trasera LH","Disco de Freno Trasero LH","Tambor de Freno Trasero LH",
      "Muñon Izquierdo","Bufa Trasera RH",
      "Tuberia de Freno Derecha","Tuberia de Freno Izquierdo","Tuberias de Frenos",
      "Brazo Tensor Superior Izquierdo","Brazo Tensor Inferior Izquierdo",
      "Brazo Tensor Superior Derecho","Brazo Tensor Inferior Derecho",
      "Brazo de Regulacion Izquierdo","Brazo de Regulacion Derecho",
      "Balero de Bufa Izquierda","Balero de Bufa Derecha",
      "Brazo de Caida Derecho","Brazo de Caida Izquierdo",
      "Tirante Inferior Derecho","Tirante Superior Derecho",
      "Tirante Inferior Izquierdo","Tirante Superior Izquierdo",
      "Barra de Caida Izquierda","Barra de Caida Derecha","Amortiguador Trasero RH"
    ],
    "Suspensión Delantera Derecha": [
      "Suspensión Delantera Derecha","Balero","Brazo Tirante","Brazo Transversal",
      "Bufa","Muñon Delantero","Perno de Brazo","Terminal de Barra Estabilizadora",
      "Terminal de Cremallera","Terminal de Dirección","Terminal de Regulación de Altura","Tuercas"
    ],
    "Suspensión Delantera Izquierda": [
      "Suspensión Delantera Izquierda","Terminal de Dirección","Terminal de Cremallera",
      "Terminal de Barra Estabilizadora","Brazo Transversal","Terminal de Regulación de Altura",
      "Muñon Delantero","Bufa","Balero","Brazo Tirante","Perno de Brazo","Tuercas"
    ],
    "Alineación": ["Alineado","Corrección de Avance"]
  },
  "🔧 Motor y Mecánica": {
    "Motor": [
      "Motor","Culata","Bloque de Motor","Precarter","Carter",
      "Alternador","Bomba de Agua","Bomba de Power Steering","Compresor",
      "Motor de Arranque","Soporte de Motor RH","Soporte de Motor LH",
      "Soporte de Motor Frontal","Soporte de Motor Trasero","Aceite",
      "Faja de Accesorios","Faja de A/C","Escape","Manifull de Admisión",
      "Unidad de Control de ABS","Conector de Unidad de Control de ABS",
      "Kit de Distribucion","Cubierta de Distribucion","Cadena de Distribucion",
      "Balero Tensor de Distribucion","Empaque de Distribucion",
      "Selladores de Distribucion","Polea de Cigueñal","Sensor MAP",
      "Cuerpo de Aceleracion","Entrada de Cuerpo de Aceleracion",
      "Sensores de Motor","Lavado de Motor","Bomba de Combustible",
      "Cubierta Inferior Protectora","Filtro de Aceite",
      "Cubierta Inferior de Motor RH","Cubierta Inferior de Motor LH","Ramal Electrico"
    ],
    "Caja de Velocidades": [
      "Caja de Velocidades","Housing de Caja de Velocidades",
      "Carter de Caja de Velocidades","Soporte Trasero","Enfriador de Aceite",
      "Tuberia de Enfriador de Aceite a Caja","Soporte de Transmision","Soporte de Caja"
    ],
    "Tanque de Combustible": [
      "Tanque de Combustible","Protecto de Tanque de Combustible",
      "Cubierta de Tanque de Combustible"
    ],
    "Combustible y filtros": ["Depósito de Filtro de Aire","Ducto de Entrada","Filtro de Aire"],
    "Diagnóstico": ["Diagnóstico"]
  },
  "⚡ Eléctrico": {
    "Sistema Eléctrico": ["Sistema Eléctrico","Secado y Sopleteado de Sistema Electrico","Caja de Fusibles","Ventolera LH"],
    "Seguridad y Sensores": [
      "Módulo de Bolsas de Aire","Sensores en General",
      "Reseteo y/o Programación de Pilotos","Limpieza de Sensores"
    ]
  },
  "🪑 Interior y Tapicería": {
    "Tablero": [
      "Tablero","Cuadrante de Marcadores","Housing de Tablero","Refuerzo de Tablero",
      "Equipo de Sonido","Rejillas de Aire Acondicionado","Switch de Intermitentes",
      "Evaporador de Aire","Blower de Aire","Consola Central","Guantera",
      "Palanca de Apertura de Capó","Bolsa de Aire de Copiloto","CD Player","DVD Player",
      "Pantalla Tactil","Soportes de Equipo de Sonido",
      "Bolsa de Aire de Rodilla Conductor","Bolsa de Aire Conductor"
    ],
    "Timón/Volante": [
      "Timón/Volante","Palanca Pide Vias","Palanca de Cricos",
      "Controles de Equipo de Sonido","Bolsa de Aire","Cincha de Pito","Cubiertas de Timon"
    ],
    "Piso de Cabina": [
      "Piso de Cabina","Pedales","Tapicerias de Piso","Asientos",
      "Palanca de Apertura de Baúl","Palanca de Apertura de Tanque",
      "Bases de Cinturones de Seguridad","Tolva Inferior RH",
      "Aislante Termico","Insulador de Piso","Abrazadera de Piso"
    ],
    "Asientos": [
      "Asiento Delantero Derecho","Asiento Delantero Izquierdo",
      "Asiento Trasero","Asientos Completos"
    ],
    "Asiento Delantero Derecho": [
      "Asiento Delantero Derecho","Tapicería","Bolsa de Aire Lateral",
      "Descansa Brazo","Cinturon de Seguridad","Pretensor Cinturon"
    ],
    "Asiento Delantero Izquierdo": [
      "Asiento Delantero Izquierdo","Tapicería","Bolsa de Aire Lateral",
      "Descansa Brazo","Cinturon de Seguridad","Pretensor Cinturon"
    ],
    "Asiento Trasero": [
      "Asiento Trasero","Base de Cinturon de Seguridad",
      "Cinturon de Seguridad Derecho","Pretensor de Cinturon Derecho",
      "Cinturon de Seguridad Izquierdo","Pretensor de Cinturon Izquierdo"
    ],
    "Asientos Completos": ["Asientos Completos","Limpieza de Tapicerias"],
    "Tapicería": ["Tapicería Completa","Limpieza de Tapicería"],
    "Tolva": ["Tolva","Tolva de Cricos"]
  },
  "🎨 Pintura y Acabados": {
    "Preparación": ["Lijado y Pulido","Enmascarar","Pegamentos Plásticos"],
    "Acabados": ["Capa Transparente","Pintura para Interiores","Blindaje"]
  },
  "🔩 Varios": {
    "Accesorios": ["Perno","Pernos"],
    "Servicios": ["Mano de Obra/Reparación","Mano de Obra","Limpieza de Chasis"]
  }
};
