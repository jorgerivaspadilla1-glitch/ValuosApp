const TALLER = {
  nombre:    'TECNI-AUTO',
  subtitulo: 'By Dinamic Power',
  direccion: '6a. Av. Norte 2-5 Santa Tecla',
  telefonos: '2229-3703 · 2556-1820 · 7851-0609',
  email:     ''
};
const HOJA = 'Registro Valuos';
const CARPETA_FOTOS = 'ValuoApp - Fotos';

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('🚗 ValuoApp')
    .addItem('📋 Ver panel de valuos', 'abrirPanel')
    .addItem('📊 Actualizar encabezados', 'crearEncabezados')
    .addItem('🖨️ Generar PDF de fila seleccionada', 'abrirPDFDesdeMenu')
    .addToUi();
}

function crearEncabezados() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HOJA);
  if (!sheet) { SpreadsheetApp.getUi().alert('No se encontró la hoja "' + HOJA + '"'); return; }
  var headers = ['Fecha','Aseguradora','Tipo','N° Siniestro','N° Póliza','Placa',
    'Teléfono','Propietario','Vehículo','Total Piezas','Total MO','Total Pintura',
    'TOTAL','Estado','Fotos','Piezas_JSON','MO_JSON','Pintura_JSON','Fotos_JSON'];
  sheet.getRange(1, 1, 1, headers.length).setValues([headers])
    .setBackground('#1a3a5c').setFontColor('#ffffff').setFontWeight('bold');
  sheet.setFrozenRows(1);
  SpreadsheetApp.getUi().alert('✅ Encabezados creados correctamente');
}

function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HOJA);
    var data = JSON.parse(e.postData.contents);

    // Si es subida de foto individual
    if (data.accion === 'subirFoto') {
      var result = subirFoto(data.base64data, data.label, data.placa, data.fecha);
      return ContentService
        .createTextOutput(JSON.stringify(result))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // Guardar fotos en Drive y obtener URLs
    var fotosUrls = [];
    if (data.fotos_data && data.fotos_data.length > 0) {
      fotosUrls = guardarFotosEnDrive(data.fotos_data, data.placa || 'valuo');
    }

    var newRow = sheet.appendRow([
      data.fecha        || '',
      data.aseguradora  || '',
      data.tipo_cliente || '',
      data.siniestro    || '',
      data.poliza       || '',
      data.placa        || '',
      data.telefono     || '',
      data.propietario  || '',
      data.vehiculo     || '',
      data.total_piezas || '0',
      data.total_mo     || '0',
      data.total_pintura|| '0',
      data.total        || '0',
      'Recibido',
      data.fotos        || '0',
      data.piezas_json  || '',
      data.mo_json      || '',
      data.pintura_json || '',
      JSON.stringify(fotosUrls)
    ]);

    // Generar documento y retornar URL
    var fila = sheet.getLastRow();
    var docUrl = '';
    try {
      docUrl = generarDocumento(fila);
      // Actualizar estado
      sheet.getRange(fila, 14).setValue('Enviado');
    } catch(docErr) {
      docUrl = '';
    }

    return ContentService
      .createTextOutput(JSON.stringify({ resultado: 'OK', docUrl: docUrl }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService
      .createTextOutput(JSON.stringify({ error: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doOptions(e) {
  return ContentService
    .createTextOutput('')
    .setMimeType(ContentService.MimeType.TEXT);
}

function guardarFotosEnDrive(fotosData, placa) {
  var carpeta;
  var carpetas = DriveApp.getFoldersByName(CARPETA_FOTOS);
  if (carpetas.hasNext()) {
    carpeta = carpetas.next();
  } else {
    carpeta = DriveApp.createFolder(CARPETA_FOTOS);
  }

  var subcarpeta = carpeta.createFolder(placa + '_' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd_HHmm'));
  var urls = [];

  fotosData.forEach(function(foto, i) {
    try {
      var base64 = foto.data.split(',')[1];
      var blob = Utilities.newBlob(Utilities.base64Decode(base64), 'image/jpeg', foto.label + '.jpg');
      var file = subcarpeta.createFile(blob);
      file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      urls.push({ label: foto.label, url: file.getDownloadUrl(), viewUrl: 'https://drive.google.com/file/d/' + file.getId() + '/view' });
    } catch(e) {
      urls.push({ label: foto.label || ('Foto ' + (i+1)), url: '', error: e.message });
    }
  });

  return urls;
}

function doGet(e) {
  if (e && e.parameter && e.parameter.accion === 'panel') {
    return HtmlService.createHtmlOutputFromFile('Panel')
      .setTitle('ValuoApp – Panel de Valuos')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }
  // Obtener URL del ultimo doc generado
  if (e && e.parameter && e.parameter.accion === 'getUltimoDoc') {
    try {
      var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HOJA);
      var lastRow = sheet.getLastRow();
      if (lastRow <= 1) {
        return ContentService
          .createTextOutput(JSON.stringify({ ok: false }))
          .setMimeType(ContentService.MimeType.JSON);
      }
      var docUrl = generarDocumento(lastRow);
      return ContentService
        .createTextOutput(JSON.stringify({ ok: true, docUrl: docUrl }))
        .setMimeType(ContentService.MimeType.JSON);
    } catch(err) {
      return ContentService
        .createTextOutput(JSON.stringify({ ok: false, error: err.message }))
        .setMimeType(ContentService.MimeType.JSON);
    }
  }
  return ContentService
    .createTextOutput(JSON.stringify({ status: 'ValuoApp activa' }))
    .setMimeType(ContentService.MimeType.JSON);
}

function abrirPanel() {
  var html = HtmlService.createHtmlOutputFromFile('Panel')
    .setTitle('Panel de Valuos');
  SpreadsheetApp.getUi().showModalDialog(html, '🚗 ValuoApp – Panel de Valuos');
}

function obtenerValuos() {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HOJA);
    var data = sheet.getDataRange().getValues();
    if (data.length <= 1) return [];
    var headers = data[0];
    var result = [];
    for (var i = 1; i < data.length; i++) {
      var row = data[i];
      var obj = {};
      for (var j = 0; j < headers.length; j++) {
        var val = row[j];
        if (val instanceof Date) {
          val = Utilities.formatDate(val, Session.getScriptTimeZone(), 'yyyy-MM-dd');
        }
        obj[String(headers[j])] = String(val || '');
      }
      obj._fila = i + 1;
      result.push(obj);
    }
    result.reverse();
    return result;
  } catch(e) {
    return [];
  }
}

function marcarEnviado(fila) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HOJA);
  sheet.getRange(fila, 14).setValue('Enviado a aseguradora');
  return 'OK';
}

function getDatosTaller() {
  return TALLER;
}

function abrirPDFDesdeMenu() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HOJA);
  var fila = sheet.getActiveCell().getRow();
  if (fila <= 1) {
    SpreadsheetApp.getUi().alert('Selecciona una fila con un valuo primero.');
    return;
  }
  var url = generarDocumento(fila);
  var html = HtmlService.createHtmlOutput(
    '<div style="font-family:Arial;padding:20px;text-align:center">' +
    '<p style="font-size:13px;margin-bottom:16px">✅ Presupuesto generado en Google Drive</p>' +
    '<a href="' + url + '" target="_blank" style="display:inline-block;padding:10px 24px;background:#1a3a5c;color:#fff;border-radius:8px;text-decoration:none;font-weight:600;font-size:13px">🖨️ Abrir presupuesto</a>' +
    '<p style="font-size:11px;color:#9ca3af;margin-top:12px">Desde ahí puedes imprimir o descargar como PDF</p>' +
    '</div>'
  ).setWidth(340).setHeight(160);
  SpreadsheetApp.getUi().showModalDialog(html, 'Presupuesto listo');
}

function generarDocumento(fila) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(HOJA);
  var data = sheet.getDataRange().getValues();
  var headers = data[0];
  var row = data[fila - 1];
  var v = {};
  for (var j = 0; j < headers.length; j++) {
    var val = row[j];
    if (val instanceof Date) {
      val = Utilities.formatDate(val, Session.getScriptTimeZone(), 'yyyy-MM-dd');
    }
    v[String(headers[j])] = String(val || '');
  }

  function parseJSON(str) {
    try { return JSON.parse(str); } catch(e) { return []; }
  }

  var piezas  = parseJSON(v['Piezas_JSON']);
  var mo      = parseJSON(v['MO_JSON']);
  var pintura = parseJSON(v['Pintura_JSON']);
  var fotos   = parseJSON(v['Fotos_JSON']);
  var tp  = parseFloat(v['Total Piezas']  || 0);
  var tm  = parseFloat(v['Total MO']      || 0);
  var tpt = parseFloat(v['Total Pintura'] || 0);
  var tot = parseFloat(v['TOTAL']         || 0);

  var docName = 'Presupuesto_' + (v['Placa'] || 'valuo') + '_' + (v['Fecha'] || '');
  var doc  = DocumentApp.create(docName);
  var body = doc.getBody();
  body.setMarginTop(36).setMarginBottom(36).setMarginLeft(54).setMarginRight(54);

  // ── ENCABEZADO ──────────────────────────────────────────────
  var t1 = body.appendParagraph('TECNI-AUTO');
  t1.setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  t1.editAsText().setFontSize(22).setBold(true).setForegroundColor('#1a3a5c').setBackgroundColor(null);

  var t2 = body.appendParagraph('By Dinamic Power');
  t2.setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  t2.editAsText().setFontSize(11).setItalic(true).setForegroundColor('#555555').setBackgroundColor(null);

  var t3 = body.appendParagraph('6a. Av. Norte 2-5 Santa Tecla  |  2229-3703 · 2556-1820 · 7851-0609');
  t3.setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  t3.editAsText().setFontSize(9).setForegroundColor('#777777').setBackgroundColor(null);

  body.appendHorizontalRule();

  var t4 = body.appendParagraph('PRESUPUESTO DE TRABAJO');
  t4.setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  t4.editAsText().setFontSize(14).setBold(true).setForegroundColor('#1a3a5c').setBackgroundColor(null);

  // ── DATOS DEL VEHÍCULO ───────────────────────────────────────
  var infoTable = body.appendTable([
    ['PROPIETARIO', v['Propietario']||'—', 'FECHA', v['Fecha']||'—'],
    ['TELÉFONO',    v['Teléfono']||'—',    'VEHÍCULO', v['Vehículo']||'—'],
    ['ASEGURADORA', v['Aseguradora']||'—', 'PLACA', v['Placa']||'—'],
    ['N° SINIESTRO',v['N° Siniestro']||'—','TIPO', v['Tipo']||'—'],
    ['N° PÓLIZA',   v['N° Póliza']||'—',   'ESTADO', v['Estado']||'—']
  ]);
  for (var r = 0; r < 5; r++) {
    infoTable.getCell(r, 0).editAsText().setFontSize(9).setBold(true).setForegroundColor('#1a3a5c').setBackgroundColor('#f0f4f8');
    infoTable.getCell(r, 2).editAsText().setFontSize(9).setBold(true).setForegroundColor('#1a3a5c').setBackgroundColor('#f0f4f8');
    infoTable.getCell(r, 1).editAsText().setFontSize(10).setBold(false).setForegroundColor('#000000').setBackgroundColor(null);
    infoTable.getCell(r, 3).editAsText().setFontSize(10).setBold(false).setForegroundColor('#000000').setBackgroundColor(null);
  }

  // ── FUNCIÓN PARA SECCIONES ───────────────────────────────────
  function addSection(titulo, items, col2label) {
    var sp = body.appendParagraph(' ');
    sp.editAsText().setFontSize(4);

    var sec = body.appendParagraph(titulo);
    sec.editAsText()
      .setFontSize(11).setBold(true)
      .setForegroundColor('#1a3a5c')
      .setBackgroundColor(null);
    sec.setSpacingBefore(4).setSpacingAfter(2);

    if (!items.length) {
      var emp = body.appendParagraph('—');
      emp.editAsText().setFontSize(10).setForegroundColor('#999999').setBackgroundColor(null);
      return;
    }

    var rows = [['Descripción', col2label, 'Costo']];
    items.forEach(function(r) {
      var sub = '$' + ((r.qty||r.cantidad||1) * (r.price||r.precio||0)).toFixed(2);
      rows.push([r.desc||r.descripcion||'', String(r.qty||r.cantidad||1), sub]);
    });

    var t = body.appendTable(rows);
    // Encabezado de tabla
    for (var c = 0; c < 3; c++) {
      t.getCell(0, c).editAsText()
        .setFontSize(9).setBold(true)
        .setForegroundColor('#1a3a5c')
        .setBackgroundColor('#e8f0fe');
    }
    // Filas de datos
    for (var ri = 1; ri < t.getNumRows(); ri++) {
      var bg = (ri % 2 === 0) ? '#f9fafb' : null;
      for (var ci = 0; ci < 3; ci++) {
        t.getCell(ri, ci).editAsText()
          .setFontSize(10).setBold(false)
          .setForegroundColor('#1a1a1a')
          .setBackgroundColor(bg);
      }
    }
  }

  addSection('MANO DE OBRA', mo, 'Horas');
  addSection('REPUESTOS SOLICITADOS', piezas, 'Cant.');
  addSection('PINTURA', pintura, 'Cant.');

  // ── TOTALES ──────────────────────────────────────────────────
  var sp2 = body.appendParagraph(' ');
  sp2.editAsText().setFontSize(4);

  var totTable = body.appendTable([
    ['Total Mano de Obra', '$' + tm.toFixed(2)],
    ['Total Repuestos',    '$' + tp.toFixed(2)],
    ['Total Pintura',      '$' + tpt.toFixed(2)],
    ['TOTAL',              '$' + tot.toFixed(2)]
  ]);
  for (var ti = 0; ti < 3; ti++) {
    totTable.getCell(ti, 0).editAsText().setFontSize(10).setForegroundColor('#374151').setBackgroundColor(null);
    totTable.getCell(ti, 1).editAsText().setFontSize(10).setForegroundColor('#374151').setBackgroundColor(null);
  }
  totTable.getCell(3, 0).editAsText().setFontSize(13).setBold(true).setForegroundColor('#1a3a5c').setBackgroundColor('#e8f0fe');
  totTable.getCell(3, 1).editAsText().setFontSize(13).setBold(true).setForegroundColor('#1a3a5c').setBackgroundColor('#e8f0fe');

  // ── OBSERVACIONES ────────────────────────────────────────────
  var obs = body.appendParagraph('OBSERVACIONES: Precios no incluyen IVA');
  obs.editAsText().setFontSize(9).setItalic(true).setForegroundColor('#92400e').setBackgroundColor('#fffbeb');

  // ── FIRMAS ───────────────────────────────────────────────────
  body.appendParagraph(' ').editAsText().setFontSize(8);
  var firmasTable = body.appendTable([['Firma del técnico', 'Firma del propietario', 'Autorizado por']]);
  for (var fc = 0; fc < 3; fc++) {
    firmasTable.getCell(0, fc).editAsText()
      .setFontSize(9).setForegroundColor('#666666').setBackgroundColor(null);
  }

  // ── FOTOS ────────────────────────────────────────────────────
  if (fotos && fotos.length > 0) {
    body.appendParagraph(' ').editAsText().setFontSize(8);
    var fotosTit = body.appendParagraph('FOTOGRAFÍAS DEL DAÑO');
    fotosTit.editAsText().setFontSize(11).setBold(true).setForegroundColor('#1a3a5c').setBackgroundColor(null);

    fotos.forEach(function(foto) {
      if (!foto.url) return;
      try {
        var fileId = foto.viewUrl ? foto.viewUrl.match(/\/d\/([^\/]+)\//)[1] : null;
        if (fileId) {
          var imgBlob = DriveApp.getFileById(fileId).getBlob();
          var img = body.appendImage(imgBlob);
          img.setWidth(300).setHeight(200);
          var cap = body.appendParagraph(foto.label || 'Foto');
          cap.editAsText().setFontSize(9).setItalic(true).setForegroundColor('#666666').setBackgroundColor(null);
          cap.setAlignment(DocumentApp.HorizontalAlignment.CENTER);
        }
      } catch(imgErr) {
        var link = body.appendParagraph('📷 ' + (foto.label||'Foto') + ': ' + foto.viewUrl);
        link.editAsText().setFontSize(10).setForegroundColor('#1a3a5c').setBackgroundColor(null);
      }
    });
  }

  // ── PIE DE PÁGINA ────────────────────────────────────────────
  body.appendParagraph(' ').editAsText().setFontSize(4);
  var footer = body.appendParagraph('Tecni-Auto · By Dinamic Power · 6a. Av. Norte 2-5 Santa Tecla · 2229-3703');
  footer.setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  footer.editAsText().setFontSize(8).setForegroundColor('#9ca3af').setBackgroundColor(null);

  doc.saveAndClose();

  var file = DriveApp.getFileById(doc.getId());
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return doc.getUrl();
}

// ── SUBIR FOTO INDIVIDUAL (llamado desde la app) ──────────────
function subirFoto(base64data, label, placa, fecha) {
  try {
    var carpeta;
    var carpetas = DriveApp.getFoldersByName(CARPETA_FOTOS);
    if (carpetas.hasNext()) {
      carpeta = carpetas.next();
    } else {
      carpeta = DriveApp.createFolder(CARPETA_FOTOS);
    }
    var nombreCarpeta = (placa || 'valuo') + '_' + (fecha || Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd'));
    var subcarpetas = carpeta.getFoldersByName(nombreCarpeta);
    var subcarpeta = subcarpetas.hasNext() ? subcarpetas.next() : carpeta.createFolder(nombreCarpeta);

    var base64 = base64data.split(',')[1];
    var blob = Utilities.newBlob(Utilities.base64Decode(base64), 'image/jpeg', label + '.jpg');
    var file = subcarpeta.createFile(blob);
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    return {
      ok: true,
      label: label,
      fileId: file.getId(),
      viewUrl: 'https://drive.google.com/file/d/' + file.getId() + '/view',
      downloadUrl: file.getDownloadUrl()
    };
  } catch(e) {
    return { ok: false, error: e.message };
  }
}
