// ===== GENERADOR DE PDF =====
function generarPDF() {
  const v = collectFormData();
  const vehiculo = [v.marca, v.modelo, v.anio].filter(Boolean).join(' ') || '—';
  const fotos = photoSlots.filter(Boolean);

  const mkRows = (items) => items.map(r => `
    <tr>
      <td>${r.desc}</td>
      <td style="text-align:center">${r.qty}</td>
      <td style="text-align:right">$${(r.qty*r.price).toFixed(2)}</td>
    </tr>`).join('');

  const fotosHTML = fotos.length ? `
    <div class="section-title" style="margin-top:24px">FOTOS DEL DAÑO</div>
    <div class="fotos-grid">
      ${fotos.map(f => `<div class="foto-item">
        <img src="${f.data}" alt="${f.label}">
        <div class="foto-label">${f.label}</div>
      </div>`).join('')}
    </div>` : '';

  const html = `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Valuo - ${v.placa}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, sans-serif; font-size: 11px; color: #1a1a1a; background: #fff; padding: 20px; }
  .header { text-align: center; margin-bottom: 16px; border-bottom: 3px solid #1a3a5c; padding-bottom: 12px; }
  .logo-text { font-size: 26px; font-weight: 900; color: #1a3a5c; letter-spacing: 2px; }
  .logo-sub { font-size: 12px; color: #666; margin-top: 2px; }
  .doc-title { font-size: 16px; font-weight: 700; text-align: center; margin: 12px 0; color: #1a3a5c; letter-spacing: 1px; }
  .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0; border: 1px solid #ccc; margin-bottom: 14px; }
  .info-row { display: grid; grid-template-columns: 130px 1fr; border-bottom: 1px solid #ddd; }
  .info-row:last-child { border-bottom: none; }
  .info-label { background: #f0f4f8; padding: 5px 8px; font-weight: 700; font-size: 10px; text-transform: uppercase; color: #1a3a5c; border-right: 1px solid #ddd; }
  .info-value { padding: 5px 8px; font-size: 11px; }
  .section-title { background: #1a3a5c; color: #fff; font-weight: 700; font-size: 11px; padding: 6px 10px; margin-bottom: 0; letter-spacing: 0.5px; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 14px; }
  thead th { background: #e8f0fe; padding: 6px 8px; font-size: 10px; font-weight: 700; text-transform: uppercase; color: #1a3a5c; border: 1px solid #ddd; }
  tbody td { padding: 5px 8px; border: 1px solid #eee; font-size: 11px; }
  tbody tr:nth-child(even) td { background: #f9fafb; }
  .totals-table { margin-top: 8px; }
  .totals-table td { padding: 5px 10px; border: none; font-size: 12px; }
  .totals-table .label { text-align: right; color: #555; }
  .totals-table .value { text-align: right; font-weight: 600; min-width: 80px; }
  .grand-total td { background: #1a3a5c; color: #fff; font-size: 14px; font-weight: 700; padding: 8px 10px; }
  .obs { border: 1px solid #f59e0b; background: #fffbeb; padding: 8px 12px; margin-top: 14px; border-radius: 4px; font-size: 10px; color: #92400e; }
  .footer { margin-top: 20px; text-align: center; font-size: 10px; color: #9ca3af; border-top: 1px solid #eee; padding-top: 10px; }
  .sign-row { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-top: 30px; }
  .sign-box { border-top: 1px solid #999; padding-top: 6px; text-align: center; font-size: 10px; color: #666; }
  .fotos-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 10px; margin-top: 10px; }
  .foto-item img { width: 100%; height: 130px; object-fit: cover; border-radius: 4px; border: 1px solid #ddd; }
  .foto-label { text-align: center; font-size: 10px; color: #666; margin-top: 3px; }
  @media print {
    body { padding: 0; }
    .no-print { display: none; }
  }
</style>
</head>
<body>

<div class="header">
  <img src="' + LOGO_DATA_URL + '" alt="Tecni-Auto" style="height:72px;max-width:300px;object-fit:contain">
  <div class="logo-sub" style="font-size:12px;color:#666;margin-top:4px">Tel. 2229-3703 &nbsp;|&nbsp; By Dinamic Power</div>
</div>

<div class="doc-title">PRESUPUESTO DE TRABAJO</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
  <div>
    <table style="border:1px solid #ccc;margin:0">
      <tr><td class="info-label" style="background:#f0f4f8;padding:5px 8px;font-weight:700;font-size:10px;text-transform:uppercase;color:#1a3a5c;border-right:1px solid #ddd;border-bottom:1px solid #ddd">Propietario</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.propietario||'—'}</td></tr>
      <tr><td class="info-label" style="background:#f0f4f8;padding:5px 8px;font-weight:700;font-size:10px;text-transform:uppercase;color:#1a3a5c;border-right:1px solid #ddd;border-bottom:1px solid #ddd">Teléfono</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.telefono||'—'}</td></tr>
      <tr><td class="info-label" style="background:#f0f4f8;padding:5px 8px;font-weight:700;font-size:10px;text-transform:uppercase;color:#1a3a5c;border-right:1px solid #ddd;border-bottom:1px solid #ddd">Aseguradora</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.aseguradora||'—'}</td></tr>
      <tr><td class="info-label" style="background:#f0f4f8;padding:5px 8px;font-weight:700;font-size:10px;text-transform:uppercase;color:#1a3a5c;border-right:1px solid #ddd;border-bottom:1px solid #ddd">N° Siniestro</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.siniestro||'—'}</td></tr>
      <tr><td class="info-label" style="background:#f0f4f8;padding:5px 8px;font-weight:700;font-size:10px;text-transform:uppercase;color:#1a3a5c;border-right:1px solid #ddd">N° Póliza</td><td style="padding:5px 8px">${v.poliza||'—'}</td></tr>
    </table>
  </div>
  <div>
    <table style="border:1px solid #ccc;margin:0">
      <tr><td class="info-label" style="background:#f0f4f8;padding:5px 8px;font-weight:700;font-size:10px;text-transform:uppercase;color:#1a3a5c;border-right:1px solid #ddd;border-bottom:1px solid #ddd">Fecha</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.fecha||'—'}</td></tr>
      <tr><td class="info-label" style="background:#f0f4f8;padding:5px 8px;font-weight:700;font-size:10px;text-transform:uppercase;color:#1a3a5c;border-right:1px solid #ddd;border-bottom:1px solid #ddd">Marca</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.marca||'—'}</td></tr>
      <tr><td class="info-label" style="background:#f0f4f8;padding:5px 8px;font-weight:700;font-size:10px;text-transform:uppercase;color:#1a3a5c;border-right:1px solid #ddd;border-bottom:1px solid #ddd">Modelo / Año</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.modelo||'—'} ${v.anio||''}</td></tr>
      <tr><td class="info-label" style="background:#f0f4f8;padding:5px 8px;font-weight:700;font-size:10px;text-transform:uppercase;color:#1a3a5c;border-right:1px solid #ddd;border-bottom:1px solid #ddd">Color</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.color||'—'}</td></tr>
      <tr><td class="info-label" style="background:#f0f4f8;padding:5px 8px;font-weight:700;font-size:10px;text-transform:uppercase;color:#1a3a5c;border-right:1px solid #ddd;border-bottom:1px solid #ddd">Tipo de Caja</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.tipo_caja||'—'}</td></tr>
      <tr><td class="info-label" style="background:#f0f4f8;padding:5px 8px;font-weight:700;font-size:10px;text-transform:uppercase;color:#1a3a5c;border-right:1px solid #ddd">N° de Rin / Placa</td><td style="padding:5px 8px">Rin ${v.num_rin||'—'} &nbsp;|&nbsp; <strong>${v.placa||'—'}</strong></td></tr>
    </table>
  </div>
</div>

${v.mo.length ? `
<div class="section-title">MANO DE OBRA</div>
<table>
  <thead><tr><th style="text-align:left">Descripción</th><th>Horas</th><th>Costo</th></tr></thead>
  <tbody>${mkRows(v.mo)}</tbody>
</table>` : ''}

${v.piezas.length ? `
<div class="section-title">REPUESTOS SOLICITADOS</div>
<table>
  <thead><tr><th style="text-align:left">Descripción</th><th>Cant.</th><th>Costo</th></tr></thead>
  <tbody>${mkRows(v.piezas)}</tbody>
</table>` : ''}

${v.pintura.length ? `
<div class="section-title">PINTURA</div>
<table>
  <thead><tr><th style="text-align:left">Material</th><th>Cant.</th><th>Costo</th></tr></thead>
  <tbody>${mkRows(v.pintura)}</tbody>
</table>` : ''}

<table class="totals-table" style="width:300px;margin-left:auto;border:1px solid #ddd">
  <tr><td class="label" style="text-align:right;padding:5px 10px;color:#555;border-bottom:1px solid #eee">Total Mano de Obra</td><td class="value" style="text-align:right;padding:5px 10px;font-weight:600;border-bottom:1px solid #eee">$${(v.totales?.m||0).toFixed(2)}</td></tr>
  <tr><td class="label" style="text-align:right;padding:5px 10px;color:#555;border-bottom:1px solid #eee">Total Repuestos</td><td class="value" style="text-align:right;padding:5px 10px;font-weight:600;border-bottom:1px solid #eee">$${(v.totales?.p||0).toFixed(2)}</td></tr>
  <tr><td class="label" style="text-align:right;padding:5px 10px;color:#555;border-bottom:1px solid #eee">Total Pintura</td><td class="value" style="text-align:right;padding:5px 10px;font-weight:600;border-bottom:1px solid #eee">$${(v.totales?.pt||0).toFixed(2)}</td></tr>
  <tr class="grand-total"><td style="text-align:right;padding:8px 10px;background:#1a3a5c;color:#fff;font-size:14px;font-weight:700">TOTAL</td><td style="text-align:right;padding:8px 10px;background:#1a3a5c;color:#fff;font-size:14px;font-weight:700">$${v.total.toFixed(2)}</td></tr>
</table>

${fotosHTML}

<div class="sign-row">
  <div class="sign-box">Firma del técnico</div>
  <div class="sign-box">Firma del propietario</div>
  <div class="sign-box">Autorizado por</div>
</div>

<div class="footer">
  Documento generado por ValuoApp · ${new Date().toLocaleDateString('es-SV')} · ${v.placa}
</div>

<div class="no-print" style="text-align:center;margin-top:20px">
  <button onclick="window.print()" style="padding:12px 30px;background:#1a3a5c;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer">🖨️ Imprimir / Guardar PDF</button>
  <button onclick="window.close()" style="padding:12px 20px;background:#f3f4f6;color:#374151;border:1px solid #ddd;border-radius:8px;font-size:14px;cursor:pointer;margin-left:10px">Cerrar</button>
</div>

</body>
</html>`;

  const win = window.open('', '_blank');
  win.document.write(html);
  win.document.close();
}
