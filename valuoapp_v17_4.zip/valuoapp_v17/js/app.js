// ===== ESTADO =====
let currentValuo = newValuoObj();
let formData = { tipo_cliente: 'Asegurado', tipo_caja: 'Mecánica' };
let photoSlots = [];
let currentPhotoSlot = null;
let catalogoVisible = false;
let zonaActual = null;

const PHOTO_LABELS = ['Frente','Lateral Izq.','Lateral Der.','Trasero','Daño 1','Daño 2'];
let photoCounter = 6;
const SHEETS_KEY = 'valuoapp_sheets_url';
const HISTORY_KEY = 'valuoapp_history';
const SHEETS_URL_DEFAULT = 'https://script.google.com/macros/s/AKfycbzspXWUqTZA1WPvpP5I9YjB6qy_GRA7YD__tidSpeq7Uz_NQmM_oIBREDnZSitvF01ieg/exec';

function newValuoObj() {
  return {
    id: Date.now(), fecha: new Date().toISOString().split('T')[0],
    aseguradora:'', tipo_cliente:'Asegurado', siniestro:'', poliza:'',
    placa:'', telefono:'', propietario:'', marca:'', modelo:'', anio:'',
    color:'', tipo_caja:'Mecánica', num_rin:'',
    piezas:[], mo:[], pintura:[],
    fotos:[], total:0, estado:'Pendiente'
  };
}

// ===== INIT =====
window.addEventListener('load', () => {
  setTimeout(() => {
    document.getElementById('splash').style.display = 'none';
    document.getElementById('app').classList.remove('hidden');
    initPhotoGrid();
    setTodayDate();
    renderZonasBtns();
  }, 1000);
});

function setTodayDate() {
  document.getElementById('fecha_valuo').value = new Date().toISOString().split('T')[0];
}

// ===== TABS =====
function showTab(name) {
  document.querySelectorAll('.tab-content').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  document.querySelector(`.nav-tab[data-tab="${name}"]`).classList.add('active');
  const names = { vehiculo:'Datos del vehículo', danos:'Daños y repuestos', fotos:'Fotos del daño', resumen:'Resumen del valuo' };
  document.getElementById('topbar-sub').textContent = names[name] || 'ValuoApp';
  if (name === 'resumen') buildResumen();
  window.scrollTo(0, 0);
}

function goToTab(name) {
  const order = ['vehiculo','danos','fotos','resumen'];
  const idx = order.indexOf(name);
  if (idx > 0) {
    const prev = document.querySelector(`.nav-tab[data-tab="${order[idx-1]}"]`);
    if (prev) { prev.classList.remove('active'); prev.classList.add('done'); }
  }
  showTab(name);
}

function showScreen(name) {
  document.getElementById('screen-valuo').classList.toggle('hidden', name !== 'valuo');
  document.getElementById('nav-tabs').classList.toggle('hidden', name !== 'valuo');
  document.getElementById('screen-historial').classList.toggle('hidden', name !== 'historial');
  if (name === 'historial') renderHistorial();
  if (name === 'valuo') document.getElementById('topbar-sub').textContent = 'Nuevo valuo';
}

function setSeg(btn, field, value) {
  btn.parentElement.querySelectorAll('.seg-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  formData[field] = value;
}

// ===== CATÁLOGO POR ZONAS =====
let piezaPrincipalActual = null;

function renderZonasBtns() {
  const container = document.getElementById('zonas-btns');
  if (!container) return;
  container.innerHTML = Object.keys(CATALOGO).map(zona =>
    '<button class="zona-pill" onclick="selectZona(this,\'' + zona.replace(/'/g,"\\'") + '\')">' + zona + '</button>'
  ).join('');
}

function selectZona(btn, zona) {
  document.querySelectorAll('.zona-pill').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  zonaActual = zona;
  piezaPrincipalActual = null;
  renderPiezasPrincipales(zona);
  document.getElementById('zona-piezas-panel').classList.remove('hidden');
}

function renderPiezasPrincipales(zona) {
  const grupos = CATALOGO[zona];
  const panel = document.getElementById('zona-piezas-list');
  let html = '<div class="subgrupo-title">Selecciona la pieza principal:</div>';
  html += '<div class="chips-row">';
  Object.keys(grupos).forEach(function(principal) {
    html += '<button class="chip-principal" onclick="selectPiezaPrincipal(this,\'' +
      principal.replace(/'/g,"\\'") + '\')">' + principal + '</button>';
  });
  html += '</div><div id="accesorios-panel" class="hidden"></div>';
  panel.innerHTML = html;
}

function selectPiezaPrincipal(btn, principal) {
  document.querySelectorAll('.chip-principal').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  piezaPrincipalActual = principal;
  const piezas = CATALOGO[zonaActual][principal];
  const panel = document.getElementById('accesorios-panel');
  const busqueda = document.getElementById('pieza-search');
  const f = busqueda ? busqueda.value.toLowerCase() : '';
  const filtradas = f ? piezas.filter(function(p) { return p.toLowerCase().includes(f); }) : piezas;
  let html = '<div class="subgrupo-title" style="margin-top:10px;color:#1a3a5c">📦 ' + principal + ' — elige piezas de soporte:</div>';
  html += '<div class="chips-row">';
  filtradas.forEach(function(p) {
    html += '<button class="chip-pieza" onclick="agregarPieza(\'' + p.replace(/'/g,"\\'") + '\')">+ ' + p + '</button>';
  });
  html += '</div>';
  panel.innerHTML = html;
  panel.classList.remove('hidden');
  panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function renderPiezasDeZona(zona, filtro) {
  renderPiezasPrincipales(zona);
}

function filtrarPiezas() {
  if (!zonaActual) return;
  if (piezaPrincipalActual) {
    const btn = document.querySelector('.chip-principal.active');
    if (btn) selectPiezaPrincipal(btn, piezaPrincipalActual);
  } else {
    renderPiezasPrincipales(zonaActual);
  }
}

function toggleCatalogo() {
  catalogoVisible = !catalogoVisible;
  const panel = document.getElementById('catalogo-panel');
  panel.classList.toggle('hidden', !catalogoVisible);
  if (catalogoVisible && !zonaActual) {
    // Seleccionar primera zona automáticamente
    const firstBtn = document.querySelector('.zona-pill');
    if (firstBtn) firstBtn.click();
  }
}

// ===== MODAL DE OPERACIÓN =====
let piezaSeleccionada = null;
let operacionSeleccionada = null;

function agregarPieza(nombre) {
  piezaSeleccionada = nombre;
  operacionSeleccionada = null;
  document.getElementById('op-modal-pieza').textContent = nombre;
  document.querySelectorAll('.op-option').forEach(o => o.classList.remove('selected'));
  document.getElementById('op-preview').classList.add('hidden');
  document.getElementById('op-btn-confirm').disabled = true;
  document.getElementById('op-modal-bg').classList.remove('hidden');
}

function selectOp(op) {
  operacionSeleccionada = op;
  document.querySelectorAll('.op-option').forEach(o => o.classList.remove('selected'));
  document.getElementById('op-' + op).classList.add('selected');
  document.getElementById('op-btn-confirm').disabled = false;
  
  const pieza = piezaSeleccionada;
  const items = [];
  if (op === 'cambio') {
    items.push({ tag: 'tag-pieza', label: 'Piezas', texto: pieza });
    items.push({ tag: 'tag-mo', label: 'Mano de obra', texto: 'Cambio de ' + pieza });
    items.push({ tag: 'tag-pintura', label: 'Pintura', texto: 'Pintura ' + pieza });
  } else if (op === 'reparacion') {
    items.push({ tag: 'tag-mo', label: 'Mano de obra', texto: 'Reparación de ' + pieza });
    items.push({ tag: 'tag-pintura', label: 'Pintura', texto: 'Pintura ' + pieza });
  } else if (op === 'dm') {
    items.push({ tag: 'tag-mo', label: 'Mano de obra', texto: 'D/M ' + pieza });
  }
  
  document.getElementById('op-preview-items').innerHTML = items.map(item =>
    '<div class="op-preview-item"><span class="tag ' + item.tag + '">' + item.label + '</span> ' + item.texto + '</div>'
  ).join('');
  document.getElementById('op-preview').classList.remove('hidden');
}

function confirmarOperacion() {
  if (!piezaSeleccionada || !operacionSeleccionada) return;
  const pieza = piezaSeleccionada;
  const op = operacionSeleccionada;

  if (op === 'cambio') {
    agregarFilaLista('lista-piezas', pieza);
    agregarFilaLista('lista-mo', 'Cambio de ' + pieza);
    agregarFilaLista('lista-pintura', 'Pintura ' + pieza);
  } else if (op === 'reparacion') {
    agregarFilaLista('lista-mo', 'Reparación de ' + pieza);
    agregarFilaLista('lista-pintura', 'Pintura ' + pieza);
  } else if (op === 'dm') {
    agregarFilaLista('lista-mo', 'D/M ' + pieza);
  }

  cerrarOpModal();
  showToast('✓ ' + pieza + ' agregada');
  calcTotals();
}

function agregarFilaLista(listId, descripcion) {
  const list = document.getElementById(listId);
  const row = document.createElement('div');
  row.className = 'item-row';
  row.innerHTML = '<input type="text" value="' + descripcion + '">' +
    '<input type="number" placeholder="1" value="1" min="0" step="any" oninput="calcTotals()">' +
    '<input type="number" placeholder="0.00" value="" min="0" step="0.01" oninput="calcTotals()">' +
    '<button class="del-btn" onclick="delItem(this)">×</button>';
  list.appendChild(row);
  row.scrollIntoView({ behavior:'smooth', block:'nearest' });
}

function cerrarOpModal() {
  document.getElementById('op-modal-bg').classList.add('hidden');
  piezaSeleccionada = null;
  operacionSeleccionada = null;
}

// ===== ITEMS MANUALES =====
function addItemRow(listId) {
  const list = document.getElementById(listId);
  const row = document.createElement('div');
  row.className = 'item-row';
  row.innerHTML = `<input type="text" placeholder="Descripción...">
    <input type="number" placeholder="0" value="1" min="0" step="any" oninput="calcTotals()">
    <input type="number" placeholder="0.00" value="" min="0" step="0.01" oninput="calcTotals()">
    <button class="del-btn" onclick="delItem(this)">×</button>`;
  list.appendChild(row);
  row.querySelector('input').focus();
}

function delItem(btn) {
  btn.closest('.item-row').remove();
  calcTotals();
}

function getListRows(listId) {
  return Array.from(document.querySelectorAll(`#${listId} .item-row`)).map(row => {
    const inputs = row.querySelectorAll('input');
    return { desc:inputs[0].value.trim(), qty:parseFloat(inputs[1].value)||0, price:parseFloat(inputs[2].value)||0 };
  }).filter(r => r.desc || r.price);
}

function getListTotal(listId) {
  return getListRows(listId).reduce((s,r) => s + r.qty * r.price, 0);
}

function calcTotals() {
  const p = getListTotal('lista-piezas');
  const m = getListTotal('lista-mo');
  const pt = getListTotal('lista-pintura');
  const grand = p + m + pt;
  document.getElementById('total-piezas').textContent = '$' + p.toFixed(2);
  document.getElementById('total-mo').textContent = '$' + m.toFixed(2);
  document.getElementById('total-pintura').textContent = '$' + pt.toFixed(2);
  document.getElementById('total-grand').textContent = '$' + grand.toFixed(2);
  return { p, m, pt, grand };
}

// ===== FOTOS =====
function initPhotoGrid() {
  const grid = document.getElementById('photo-grid');
  grid.innerHTML = '';
  photoSlots = [];
  photoCounter = 0;
  PHOTO_LABELS.forEach(label => agregarSlotFoto(label));
  updateDownloadSection();
}

function agregarSlotFoto(label) {
  const grid = document.getElementById('photo-grid');
  const idx = photoCounter++;
  photoSlots.push(null);
  const slot = document.createElement('div');
  slot.className = 'photo-slot';
  slot.dataset.index = idx;
  slot.innerHTML = '<span class="slot-icon">📷</span>' +
    '<input class="slot-label-input" type="text" value="' + (label || ('Foto ' + (idx+1))) + '" ' +
    'onclick="event.stopPropagation()" placeholder="Etiqueta...">' ;
  slot.onclick = function() { openCamera(idx); };
  grid.appendChild(slot);
}

function agregarNuevoSlot() {
  agregarSlotFoto('Foto ' + (photoCounter + 1));
  showToast('Nuevo espacio de foto agregado');
}

function openCamera(idx) {
  currentPhotoSlot = idx;
  document.getElementById('file-input').click();
}

function handlePhoto(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    const slot = document.querySelector(`.photo-slot[data-index="${currentPhotoSlot}"]`);
    const labelInput = slot ? slot.querySelector('.slot-label-input') : null;
    const label = labelInput ? labelInput.value.trim() : ('Foto ' + (currentPhotoSlot + 1));
    photoSlots[currentPhotoSlot] = { data: e.target.result, label: label };
    if (slot) {
      slot.innerHTML = '<img src="' + e.target.result + '" alt="foto"><div class="photo-overlay">📥</div>';
      slot.classList.add('has-photo');
      slot.onclick = function() { mostrarOpcionFoto(currentPhotoSlot); };
    }
    updateDownloadSection();
    showToast('Foto guardada ✓');
  };
  reader.readAsDataURL(file);
  event.target.value = '';
}

function mostrarOpcionFoto(idx) {
  if (!photoSlots[idx]) { openCamera(idx); return; }
  if (confirm('Aceptar = Descargar JPEG\nCancelar = Cambiar foto')) {
    descargarFoto(idx);
  } else {
    currentPhotoSlot = idx;
    document.getElementById('file-input').click();
  }
}

function descargarFoto(idx) {
  const foto = photoSlots[idx];
  if (!foto) return;
  const a = document.createElement('a');
  a.href = foto.data;
  const placa = document.getElementById('placa').value || 'valuo';
  a.download = `${placa}_${foto.label.replace(/\./g,'').replace(/ /g,'_')}.jpg`;
  a.click();
  showToast('📥 Descargando ' + foto.label);
}

function updateDownloadSection() {
  const fotos = photoSlots.filter(Boolean);
  const section = document.getElementById('fotos-download-section');
  const list = document.getElementById('fotos-download-list');
  if (!fotos.length) { section.classList.add('hidden'); return; }
  section.classList.remove('hidden');
  list.innerHTML = fotos.map((f) => {
    const realIdx = photoSlots.indexOf(f);
    return `<div class="download-row">
      <img src="${f.data}" class="thumb">
      <span class="thumb-label">${f.label}</span>
      <button class="btn-download" onclick="descargarFoto(${realIdx})">📥 JPEG</button>
    </div>`;
  }).join('') + `<button class="btn-primary" style="margin-top:10px;width:100%" onclick="descargarTodasFotos()">📥 Descargar todas</button>`;
}

function descargarTodasFotos() {
  const fotos = photoSlots.filter(Boolean);
  if (!fotos.length) { showToast('No hay fotos'); return; }
  const placa = document.getElementById('placa').value || 'valuo';
  fotos.forEach((f, i) => {
    setTimeout(() => {
      const a = document.createElement('a');
      a.href = f.data;
      a.download = `${placa}_${f.label.replace(/\./g,'').replace(/ /g,'_')}.jpg`;
      a.click();
    }, i * 500);
  });
  showToast(`📥 Descargando ${fotos.length} fotos...`);
}

// ===== RECOPILAR DATOS =====
function collectFormData() {
  const v = currentValuo;
  v.aseguradora = document.getElementById('aseguradora').value;
  v.tipo_cliente = formData.tipo_cliente || 'Asegurado';
  v.siniestro = document.getElementById('siniestro').value.trim();
  v.poliza = document.getElementById('poliza').value.trim();
  v.placa = document.getElementById('placa').value.trim();
  v.telefono = document.getElementById('telefono').value.trim();
  v.propietario = document.getElementById('propietario').value.trim();
  v.marca = document.getElementById('marca').value.trim();
  v.modelo = document.getElementById('modelo').value.trim();
  v.anio = document.getElementById('anio').value.trim();
  v.color = document.getElementById('color_vehiculo').value.trim();
  v.tipo_caja = formData.tipo_caja || 'Mecánica';
  v.num_rin = document.getElementById('num_rin').value.trim();
  v.fecha = document.getElementById('fecha_valuo').value;
  v.piezas = getListRows('lista-piezas');
  v.mo = getListRows('lista-mo');
  v.pintura = getListRows('lista-pintura');
  v.fotos = photoSlots.filter(Boolean).length;
  const totals = calcTotals();
  v.total = totals.grand;
  v.totales = totals;
  return v;
}

// ===== RESUMEN =====
function buildResumen() {
  const v = collectFormData();
  const vehiculo = [v.marca, v.modelo, v.anio].filter(Boolean).join(' ') || '—';
  const mkRows = (items) => items.map(r =>
    `<tr><td>${r.desc}</td><td style="text-align:center">${r.qty}</td><td style="text-align:right">$${(r.qty*r.price).toFixed(2)}</td></tr>`).join('');

  document.getElementById('resumen-content').innerHTML = `
    <div class="resumen-group">
      <h4>Datos del vehículo</h4>
      <div class="resumen-grid">
        <div class="resumen-item"><div class="resumen-label">Aseguradora</div><div class="resumen-value">${v.aseguradora||'—'}</div></div>
        <div class="resumen-item"><div class="resumen-label">Tipo</div><div class="resumen-value">${v.tipo_cliente}</div></div>
        <div class="resumen-item"><div class="resumen-label">N° Siniestro</div><div class="resumen-value">${v.siniestro||'—'}</div></div>
        <div class="resumen-item"><div class="resumen-label">N° Póliza</div><div class="resumen-value">${v.poliza||'—'}</div></div>
        <div class="resumen-item"><div class="resumen-label">Placa</div><div class="resumen-value">${v.placa||'—'}</div></div>
        <div class="resumen-item"><div class="resumen-label">Teléfono</div><div class="resumen-value">${v.telefono||'—'}</div></div>
        <div class="resumen-item"><div class="resumen-label">Propietario</div><div class="resumen-value">${v.propietario||'—'}</div></div>
        <div class="resumen-item"><div class="resumen-label">Vehículo</div><div class="resumen-value">${vehiculo}</div></div>
        <div class="resumen-item"><div class="resumen-label">Color</div><div class="resumen-value">${v.color||'—'}</div></div>
        <div class="resumen-item"><div class="resumen-label">Tipo de caja</div><div class="resumen-value">${v.tipo_caja||'—'}</div></div>
        <div class="resumen-item"><div class="resumen-label">N° de Rin</div><div class="resumen-value">${v.num_rin||'—'}</div></div>
        <div class="resumen-item"><div class="resumen-label">Fecha</div><div class="resumen-value">${v.fecha||'—'}</div></div>
      </div>
    </div>
    ${v.piezas.length ? `<div class="resumen-group"><h4>🔧 Piezas / Repuestos</h4>
      <table class="resumen-table"><thead><tr><th>Descripción</th><th>Cant.</th><th>Subtotal</th></tr></thead>
      <tbody>${mkRows(v.piezas)}</tbody></table></div>` : ''}
    ${v.mo.length ? `<div class="resumen-group"><h4>👷 Mano de obra</h4>
      <table class="resumen-table"><thead><tr><th>Descripción</th><th>Horas</th><th>Subtotal</th></tr></thead>
      <tbody>${mkRows(v.mo)}</tbody></table></div>` : ''}
    ${v.pintura.length ? `<div class="resumen-group"><h4>🎨 Pintura</h4>
      <table class="resumen-table"><thead><tr><th>Material</th><th>Cant.</th><th>Subtotal</th></tr></thead>
      <tbody>${mkRows(v.pintura)}</tbody></table></div>` : ''}
    <div class="resumen-group">
      <h4>Total</h4>
      <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0">
        <span class="resumen-total">$${v.total.toFixed(2)}</span>
        <span class="status-chip ${v.estado==='Enviado'?'chip-sent':'chip-pending'}" id="estado-chip">${v.estado}</span>
      </div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px">${v.fotos} foto(s) adjunta(s)</div>
    </div>
    <div id="sync-result"></div>`;
}

// ===== ENVIAR A SHEETS =====
async function enviarASheets() {
  const v = collectFormData();
  if (!v.aseguradora || !v.poliza || !v.placa) {
    showToast('⚠️ Completa aseguradora, póliza y placa'); return;
  }
  const url = localStorage.getItem(SHEETS_KEY) || SHEETS_URL_DEFAULT;
  const res = document.getElementById('sync-result');

  // Paso 1: Subir fotos a Drive
  const fotosConDatos = photoSlots.filter(Boolean);
  let fotosUrls = [];
  if (fotosConDatos.length > 0) {
    showToast('📷 Subiendo ' + fotosConDatos.length + ' foto(s)...');
    if (res) res.innerHTML = '<div class="sync-status sync-info">📷 Subiendo fotos a Google Drive...</div>';
    for (let i = 0; i < fotosConDatos.length; i++) {
      const foto = fotosConDatos[i];
      try {
        const r = await fetch(url, {
          method: 'POST', mode: 'no-cors',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            accion: 'subirFoto',
            base64data: foto.data,
            label: foto.label,
            placa: v.placa,
            fecha: v.fecha
          })
        });
        fotosUrls.push({ label: foto.label, ok: true });
      } catch(e) {
        fotosUrls.push({ label: foto.label, ok: false });
      }
    }
  }

  // Paso 2: Enviar valuo
  showToast('☁️ Enviando valuo...');
  const payload = {
    fecha: v.fecha, aseguradora: v.aseguradora, tipo_cliente: v.tipo_cliente,
    siniestro: v.siniestro, poliza: v.poliza, placa: v.placa,
    telefono: v.telefono, propietario: v.propietario,
    vehiculo: [v.marca, v.modelo, v.anio].filter(Boolean).join(' '),
    color: v.color, descripcion: v.descripcion,
    total_piezas: (v.totales?.p||0).toFixed(2),
    total_mo: (v.totales?.m||0).toFixed(2),
    total_pintura: (v.totales?.pt||0).toFixed(2),
    total: v.total.toFixed(2),
    estado: 'Enviado', fotos: v.fotos,
    piezas_json: JSON.stringify(v.piezas),
    mo_json: JSON.stringify(v.mo),
    pintura_json: JSON.stringify(v.pintura),
    fotos_data: fotosConDatos.map(f => ({ data: f.data, label: f.label }))
  };

  try {
    let docUrl = '';
    // Paso 1: Enviar valuo con no-cors
    await fetch(url, {
      method: 'POST', mode: 'no-cors',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    // Paso 2: Esperar procesamiento y pedir URL del doc via GET
    await new Promise(r => setTimeout(r, 4000));
    try {
      const getResp = await fetch(url + '?accion=getUltimoDoc', { mode: 'cors' });
      const getData = await getResp.json();
      docUrl = getData.docUrl || '';
    } catch(e) { docUrl = ''; }

        v.estado = 'Enviado';
    v.docUrl = docUrl;
    saveToHistory(v);
    showToast('✅ Valuo enviado correctamente');
    const chip = document.getElementById('estado-chip');
    if (chip) { chip.textContent = 'Enviado'; chip.className = 'status-chip chip-sent'; }

    // Construir mensaje WhatsApp
    var vehiculo = [v.marca, v.modelo, v.anio].filter(Boolean).join(' ') || '-';
    var lineas = [];
    lineas.push('PRESUPUESTO TECNI-AUTO');
    lineas.push('------------------');
    lineas.push('Vehiculo: ' + vehiculo);
    lineas.push('Placa: ' + v.placa);
    lineas.push('Propietario: ' + v.propietario);
    lineas.push('Tel: ' + (v.telefono || '-'));
    lineas.push('Aseguradora: ' + v.aseguradora);
    lineas.push('Poliza: ' + v.poliza);
    if (v.siniestro) lineas.push('Siniestro: ' + v.siniestro);
    lineas.push('Fecha: ' + v.fecha);
    lineas.push('------------------');
    lineas.push('Mano de obra: $' + (v.totales && v.totales.m ? v.totales.m.toFixed(2) : '0.00'));
    lineas.push('Repuestos: $' + (v.totales && v.totales.p ? v.totales.p.toFixed(2) : '0.00'));
    lineas.push('Pintura: $' + (v.totales && v.totales.pt ? v.totales.pt.toFixed(2) : '0.00'));
    lineas.push('------------------');
    lineas.push('TOTAL: $' + v.total.toFixed(2));
    lineas.push('------------------');
    lineas.push('Tecni-Auto · 2229-3703');
    if (docUrl) lineas.push('Ver presupuesto completo: ' + docUrl);
    var msgWA = encodeURIComponent(lineas.join('\n'));

        if (res) res.innerHTML =
      '<div class="sync-status sync-ok" style="flex-direction:column;align-items:flex-start;gap:8px">' +
      '<span>✅ Valuo enviado · ' + new Date().toLocaleTimeString() + '</span>' +
      '<a href="https://wa.me/?text=' + msgWA + '" target="_blank" ' +
      'style="display:flex;align-items:center;gap:6px;padding:8px 14px;background:#25D366;color:#fff;border-radius:8px;text-decoration:none;font-size:13px;font-weight:600;width:100%;justify-content:center">' +
      '📲 Compartir por WhatsApp</a>' +
      '</div>';
  } catch(err) {
    showToast('❌ Error: ' + err.message);
    if (res) res.innerHTML = '<div class="sync-status sync-err">❌ Error al enviar</div>';
  }
}

// ===== HISTORIAL =====
function saveToHistory(v) {
  const history = JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]');
  const idx = history.findIndex(h => h.id === v.id);
  if (idx >= 0) history[idx] = v; else history.unshift(v);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
}

function renderHistorial() {
  const list = document.getElementById('historial-list');
  const history = JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]');
  if (!history.length) {
    list.innerHTML = `<div class="historial-empty"><div class="empty-icon">📋</div><p>No hay valuos guardados aún.</p></div>`;
    return;
  }
  list.innerHTML = history.map(v => `
    <div class="historial-item">
      <div class="hist-icon">🚗</div>
      <div class="hist-info">
        <p>${v.propietario||v.placa||'Sin nombre'}</p>
        <p>${v.aseguradora} · ${v.placa} · ${v.fecha}</p>
      </div>
      <div class="hist-right">
        <div class="hist-total">$${parseFloat(v.total||0).toFixed(2)}</div>
        <span class="status-chip ${v.estado==='Enviado'?'chip-sent':'chip-pending'}">${v.estado||'Pendiente'}</span>
      </div>
    </div>`).join('');
}

function exportarTodoCSV() {
  const history = JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]');
  if (!history.length) { showToast('No hay valuos'); return; }
  const headers = ['Fecha','Aseguradora','Tipo','Siniestro','Póliza','Placa','Teléfono','Propietario','Vehículo','Total','Estado'];
  const rows = history.map(v => [
    v.fecha, v.aseguradora, v.tipo_cliente, v.siniestro||'', v.poliza,
    v.placa, v.telefono||'', v.propietario,
    [v.marca,v.modelo,v.anio].filter(Boolean).join(' '),
    parseFloat(v.total||0).toFixed(2), v.estado
  ]);
  const csv = [headers,...rows].map(r=>r.map(c=>`"${c}"`).join(',')).join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));
  a.download = `valuos_${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  showToast('CSV descargado ✓');
}

// ===== TELEGRAM =====
const TG_KEY = 'valuoapp_tg_token';
const TG_CHAT_KEY = 'valuoapp_tg_chatid';

function enviarTelegram() {
  const token = localStorage.getItem(TG_KEY);
  const chatId = localStorage.getItem(TG_CHAT_KEY);
  if (!token || !chatId) {
    // Mostrar modal de configuración
    document.getElementById('tg-token').value = token || '';
    document.getElementById('tg-chatid').value = chatId || '';
    document.getElementById('modal-telegram').classList.remove('hidden');
    return;
  }
  _doEnviarTelegram(token, chatId);
}

function guardarConfigTelegram() {
  const token = document.getElementById('tg-token').value.trim();
  const chatId = document.getElementById('tg-chatid').value.trim();
  if (!token || !chatId) { showToast('⚠️ Completa Token y Chat ID'); return; }
  localStorage.setItem(TG_KEY, token);
  localStorage.setItem(TG_CHAT_KEY, chatId);
  closeTgModal();
  _doEnviarTelegram(token, chatId);
}

function closeTgModal() {
  document.getElementById('modal-telegram').classList.add('hidden');
}

async function _doEnviarTelegram(token, chatId) {
  const v = collectFormData();
  if (!v.placa) { showToast('⚠️ Completa al menos la placa'); return; }

  const res = document.getElementById('sync-result');
  if (res) res.innerHTML = '<div class="sync-status sync-info">✈️ Generando PDF y enviando...</div>';
  showToast('✈️ Preparando envío...');

  // 1. Generar HTML del PDF como string
  const pdfHTML = _buildPDFHTML(v);

  // 2. Armar texto del mensaje
  const vehiculo = [v.marca, v.modelo, v.anio].filter(Boolean).join(' ') || '—';
  const texto = [
    '🚗 *PRESUPUESTO TECNI-AUTO*',
    '──────────────────',
    `📋 Siniestro: ${v.siniestro || '—'}`,
    `📋 Póliza: ${v.poliza || '—'}`,
    `🚗 Vehículo: ${vehiculo}`,
    `⚙️ Caja: ${v.tipo_caja || '—'}  |  🔩 Rin: ${v.num_rin || '—'}`,
    `🎨 Color: ${v.color || '—'}`,
    `🔑 Placa: ${v.placa || '—'}`,
    `👤 Propietario: ${v.propietario || '—'}`,
    `📞 Tel: ${v.telefono || '—'}`,
    `🏢 Aseguradora: ${v.aseguradora || '—'}`,
    `📅 Fecha: ${v.fecha || '—'}`,
    '──────────────────',
    `🔧 Mano de obra:  $${(v.totales?.m || 0).toFixed(2)}`,
    `🔩 Repuestos:     $${(v.totales?.p || 0).toFixed(2)}`,
    `🎨 Pintura:       $${(v.totales?.pt || 0).toFixed(2)}`,
    '──────────────────',
    `💰 *TOTAL: $${v.total.toFixed(2)}*`,
    '──────────────────',
    `_Tecni-Auto · 2229-3703_`
  ].join('\n');

  const apiBase = `https://api.telegram.org/bot${token}`;

  try {
    // 3. Enviar mensaje de texto primero
    await fetch(`${apiBase}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: texto, parse_mode: 'Markdown' })
    });

    // 4. Enviar fotos una por una como album o individuales
    const fotos = photoSlots.filter(Boolean);
    if (fotos.length > 0) {
      showToast(`📷 Enviando ${fotos.length} foto(s)...`);
      if (res) res.innerHTML = '<div class="sync-status sync-info">📷 Enviando fotos...</div>';

      for (let i = 0; i < fotos.length; i++) {
        const foto = fotos[i];
        // Convertir base64 a Blob
        const blob = _base64ToBlob(foto.data);
        const formData = new FormData();
        formData.append('chat_id', chatId);
        formData.append('photo', blob, `${v.placa}_${foto.label}.jpg`);
        formData.append('caption', i === 0 ? `📷 Fotos — ${v.placa} · ${vehiculo}` : foto.label);
        await fetch(`${apiBase}/sendPhoto`, { method: 'POST', body: formData });
      }
    }

    // 5. Enviar HTML del presupuesto como documento
    showToast('📄 Enviando presupuesto HTML...');
    const htmlBlob = new Blob([pdfHTML], { type: 'text/html' });
    const docForm = new FormData();
    docForm.append('chat_id', chatId);
    docForm.append('document', htmlBlob, `Presupuesto_${v.placa}_${v.fecha}.html`);
    docForm.append('caption', `📄 Presupuesto completo · ${v.placa}`);
    await fetch(`${apiBase}/sendDocument`, { method: 'POST', body: docForm });

    showToast('✅ Enviado a Telegram');
    if (res) res.innerHTML = '<div class="sync-status sync-ok">✅ Enviado a Telegram · ' + new Date().toLocaleTimeString() + '</div>';

  } catch (err) {
    showToast('❌ Error: ' + err.message);
    if (res) res.innerHTML = '<div class="sync-status sync-err">❌ Error al enviar a Telegram</div>';
  }
}

function _base64ToBlob(dataUrl) {
  const parts = dataUrl.split(',');
  const mime = parts[0].match(/:(.*?);/)[1];
  const raw = atob(parts[1]);
  const arr = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
  return new Blob([arr], { type: mime });
}

// Extrae el HTML del PDF como string (sin abrir ventana)
function _buildPDFHTML(v) {
  // Reutiliza la misma lógica de pdf.js pero retorna string en vez de abrir ventana
  const vehiculo = [v.marca, v.modelo, v.anio].filter(Boolean).join(' ') || '—';
  const fotos = photoSlots.filter(Boolean);
  const mkRows = (items) => items.map(r =>
    `<tr><td>${r.desc}</td><td style="text-align:center">${r.qty}</td><td style="text-align:right">$${(r.qty * r.price).toFixed(2)}</td></tr>`
  ).join('');
  const fotosHTML = fotos.length ? `
    <div class="section-title" style="margin-top:24px">FOTOS DEL DAÑO</div>
    <div class="fotos-grid">
      ${fotos.map(f => `<div class="foto-item"><img src="${f.data}" alt="${f.label}"><div class="foto-label">${f.label}</div></div>`).join('')}
    </div>` : '';

  return `<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8">
<title>Presupuesto - ${v.placa}</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Arial,sans-serif;font-size:11px;color:#1a1a1a;background:#fff;padding:20px}
.header{text-align:center;margin-bottom:16px;border-bottom:3px solid #1a3a5c;padding-bottom:12px}
.logo-text{font-size:26px;font-weight:900;color:#1a3a5c;letter-spacing:2px}
.logo-sub{font-size:12px;color:#666;margin-top:2px}
.doc-title{font-size:16px;font-weight:700;text-align:center;margin:12px 0;color:#1a3a5c}
.section-title{background:#1a3a5c;color:#fff;font-weight:700;font-size:11px;padding:6px 10px;margin-bottom:0}
table{width:100%;border-collapse:collapse;margin-bottom:14px}
thead th{background:#e8f0fe;padding:6px 8px;font-size:10px;font-weight:700;text-transform:uppercase;color:#1a3a5c;border:1px solid #ddd}
tbody td{padding:5px 8px;border:1px solid #eee;font-size:11px}
tbody tr:nth-child(even) td{background:#f9fafb}
.il{background:#f0f4f8;padding:5px 8px;font-weight:700;font-size:10px;text-transform:uppercase;color:#1a3a5c;border-right:1px solid #ddd}
.grand-total td{background:#1a3a5c;color:#fff;font-size:14px;font-weight:700;padding:8px 10px}
.fotos-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:10px}
.foto-item img{width:100%;height:130px;object-fit:cover;border-radius:4px;border:1px solid #ddd}
.foto-label{text-align:center;font-size:10px;color:#666;margin-top:3px}
.sign-row{display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;margin-top:30px}
.sign-box{border-top:1px solid #999;padding-top:6px;text-align:center;font-size:10px;color:#666}
.footer{margin-top:20px;text-align:center;font-size:10px;color:#9ca3af;border-top:1px solid #eee;padding-top:10px}
</style></head><body>
<div class="header"><img src="' + LOGO_DATA_URL + '" alt="Tecni-Auto" style="height:64px;max-width:280px;object-fit:contain"><div class="logo-sub" style="font-size:12px;color:#666;margin-top:4px">Tel. 2229-3703</div></div>
<div class="doc-title">PRESUPUESTO DE TRABAJO</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
  <div><table style="border:1px solid #ccc;margin:0">
    <tr><td class="il" style="border-bottom:1px solid #ddd">Propietario</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.propietario || '—'}</td></tr>
    <tr><td class="il" style="border-bottom:1px solid #ddd">Teléfono</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.telefono || '—'}</td></tr>
    <tr><td class="il" style="border-bottom:1px solid #ddd">Aseguradora</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.aseguradora || '—'}</td></tr>
    <tr><td class="il" style="border-bottom:1px solid #ddd">N° Siniestro</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.siniestro || '—'}</td></tr>
    <tr><td class="il">N° Póliza</td><td style="padding:5px 8px">${v.poliza || '—'}</td></tr>
  </table></div>
  <div><table style="border:1px solid #ccc;margin:0">
    <tr><td class="il" style="border-bottom:1px solid #ddd">Fecha</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.fecha || '—'}</td></tr>
    <tr><td class="il" style="border-bottom:1px solid #ddd">Marca / Modelo</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.marca || '—'} ${v.modelo || ''} ${v.anio || ''}</td></tr>
    <tr><td class="il" style="border-bottom:1px solid #ddd">Color</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.color || '—'}</td></tr>
    <tr><td class="il" style="border-bottom:1px solid #ddd">Tipo de caja</td><td style="padding:5px 8px;border-bottom:1px solid #ddd">${v.tipo_caja || '—'}</td></tr>
    <tr><td class="il">Rin / Placa</td><td style="padding:5px 8px">Rin ${v.num_rin || '—'} | <strong>${v.placa || '—'}</strong></td></tr>
  </table></div>
</div>
${v.mo.length ? `<div class="section-title">MANO DE OBRA</div><table><thead><tr><th style="text-align:left">Descripción</th><th>Horas</th><th>Costo</th></tr></thead><tbody>${mkRows(v.mo)}</tbody></table>` : ''}
${v.piezas.length ? `<div class="section-title">REPUESTOS</div><table><thead><tr><th style="text-align:left">Descripción</th><th>Cant.</th><th>Costo</th></tr></thead><tbody>${mkRows(v.piezas)}</tbody></table>` : ''}
${v.pintura.length ? `<div class="section-title">PINTURA</div><table><thead><tr><th style="text-align:left">Material</th><th>Cant.</th><th>Costo</th></tr></thead><tbody>${mkRows(v.pintura)}</tbody></table>` : ''}
<table style="width:300px;margin-left:auto;border:1px solid #ddd">
  <tr><td style="text-align:right;padding:5px 10px;color:#555;border-bottom:1px solid #eee">Mano de obra</td><td style="text-align:right;padding:5px 10px;font-weight:600;border-bottom:1px solid #eee">$${(v.totales?.m || 0).toFixed(2)}</td></tr>
  <tr><td style="text-align:right;padding:5px 10px;color:#555;border-bottom:1px solid #eee">Repuestos</td><td style="text-align:right;padding:5px 10px;font-weight:600;border-bottom:1px solid #eee">$${(v.totales?.p || 0).toFixed(2)}</td></tr>
  <tr><td style="text-align:right;padding:5px 10px;color:#555;border-bottom:1px solid #eee">Pintura</td><td style="text-align:right;padding:5px 10px;font-weight:600;border-bottom:1px solid #eee">$${(v.totales?.pt || 0).toFixed(2)}</td></tr>
  <tr class="grand-total"><td style="text-align:right;padding:8px 10px;background:#1a3a5c;color:#fff;font-size:14px;font-weight:700">TOTAL</td><td style="text-align:right;padding:8px 10px;background:#1a3a5c;color:#fff;font-size:14px;font-weight:700">$${v.total.toFixed(2)}</td></tr>
</table>
${fotosHTML}
<div class="sign-row">
  <div class="sign-box">Firma del técnico</div>
  <div class="sign-box">Firma del propietario</div>
  <div class="sign-box">Autorizado por</div>
</div>
<div class="footer">Tecni-Auto · ${new Date().toLocaleDateString('es-SV')} · ${v.placa}</div>
</body></html>`;
}

// ===== COMPARTIR TEXTO =====
function compartirValuo() {
  const v = collectFormData();
  const vehiculo = [v.marca, v.modelo, v.anio].filter(Boolean).join(' ')||'—';
  const texto = `*VALUO DE DAÑOS*\n📋 Siniestro: ${v.siniestro||'—'}\n📋 Póliza: ${v.poliza}\n🚗 Vehículo: ${vehiculo}\n⚙️ Caja: ${v.tipo_caja||'—'} | 🔩 Rin: ${v.num_rin||'—'}\n🔑 Placa: ${v.placa}\n👤 Propietario: ${v.propietario}\n📞 Tel: ${v.telefono||'—'}\n🏢 Aseguradora: ${v.aseguradora}\n📅 Fecha: ${v.fecha}\n\n💰 Piezas: $${(v.totales?.p||0).toFixed(2)}\n💰 Mano de obra: $${(v.totales?.m||0).toFixed(2)}\n💰 Pintura: $${(v.totales?.pt||0).toFixed(2)}\n*TOTAL: $${v.total.toFixed(2)}*`;
  if (navigator.share) {
    navigator.share({ title:'Valuo de daños', text:texto }).catch(()=>{});
  } else {
    navigator.clipboard.writeText(texto).then(()=>showToast('Copiado al portapapeles ✓'));
  }
}

// ===== NUEVO VALUO =====
function nuevoValuo() {
  if (!confirm('¿Iniciar un nuevo valuo? Los datos no guardados se perderán.')) return;
  currentValuo = newValuoObj();
  formData = { tipo_cliente: 'Asegurado' };
  ['aseguradora','siniestro','poliza','placa','telefono','propietario','marca','modelo','anio','color_vehiculo','num_rin'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  formData = { tipo_cliente: 'Asegurado', tipo_caja: 'Mecánica' };
  document.querySelectorAll('.seg-btn').forEach((b,i) => b.classList.toggle('active', i===0));
  ['lista-piezas','lista-mo','lista-pintura'].forEach(id => document.getElementById(id).innerHTML = '');
  calcTotals();
  initPhotoGrid();
  setTodayDate();
  catalogoVisible = false;
  zonaActual = null;
  const cp = document.getElementById('catalogo-panel');
  if (cp) cp.classList.add('hidden');
  document.querySelectorAll('.zona-pill').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.nav-tab').forEach((t,i) => { t.classList.remove('active','done'); if(i===0) t.classList.add('active'); });
  showTab('vehiculo');
  showScreen('valuo');
  showToast('Nuevo valuo iniciado');
}

// ===== SHEETS CONFIG =====
function guardarConfigSheets() {
  const url = document.getElementById('sheets-url').value.trim();
  if (!url.startsWith('https://script.google.com/')) { showToast('URL inválida'); return; }
  localStorage.setItem(SHEETS_KEY, url);
  closeModal();
  showToast('✅ Sheets configurado');
  setTimeout(() => enviarASheets(), 500);
}

function closeModal() {
  document.getElementById('modal-sheets').classList.add('hidden');
}

// ===== TOAST =====
let toastTimer;
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
}
